package net.s5games.mafia.beans;

/**
 * Created by IntelliJ IDEA.
 * User: tenchi
 * Date: Jul 8, 2008
 * Time: 8:46:08 PM
 * To change this template use File | Settings | File Templates.
 */
public enum Armor {
    PIERCE, BASH, SLASH, MAGIC
}
