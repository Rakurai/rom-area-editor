package net.s5games.mafia.ui.armor;

import net.s5games.mafia.beans.Armor;

/**
 * Created by IntelliJ IDEA.
 * User: tenchi
 * Date: Jul 8, 2008
 * Time: 8:45:26 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ArmorForm {
    public void setArmor(Armor type, int value);
}
