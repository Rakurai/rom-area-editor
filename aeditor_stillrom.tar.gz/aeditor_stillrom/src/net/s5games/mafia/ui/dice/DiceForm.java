package net.s5games.mafia.ui.dice;

import net.s5games.mafia.beans.Dice;

/**
 * Created by IntelliJ IDEA.
 * User: tenchi
 * Date: Jul 8, 2008
 * Time: 10:39:25 PM
 * To change this template use File | Settings | File Templates.
 */
public interface DiceForm {

    public void setDice(String name, Dice dice);

}
